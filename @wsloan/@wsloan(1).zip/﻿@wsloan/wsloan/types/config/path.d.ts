export default interface path {
  ACTIVE_HOST: string;
  BBS_API: string;
  BBS_HOST: string;
  BBS_HOST_OLD: string;
  BBS_HOST_PC: string;
  EX_HOST: string;
  HOST: string;
  HOSTS: string;
  MOBILE: string;
  PATH_FILE: string;
  PATH_IMAGES: string;
  PATH_PIC: string;
  PATH_QZTP: string;
  PATH_YHTX: string;
  dirname: string;
}