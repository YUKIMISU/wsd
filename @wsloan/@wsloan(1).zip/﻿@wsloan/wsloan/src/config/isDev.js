window.isDev = true ; 
module.exports = function(){
    
    return true;
}