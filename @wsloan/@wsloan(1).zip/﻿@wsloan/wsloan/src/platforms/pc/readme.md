组件命名规范
require("components/[components-name]/create.js")
<div id="J_ComponentsName"></div>