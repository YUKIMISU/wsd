var json=require('../libs/json2/json2.min.js')
module.exports = json;
