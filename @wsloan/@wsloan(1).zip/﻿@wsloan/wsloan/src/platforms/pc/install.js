var ajax = require("./utils/ajax")

module.exports = function (wsloan) {
  window.wsloan = wsloan
}