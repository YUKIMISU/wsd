var stringify = require('./stringify'),
    parse = require('./parse');
module.exports = {
    stringify: stringify,
    parse: parse
};