module.exports = {
    checkIsNewUser: function () {
        
    }
}