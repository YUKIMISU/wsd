var $ = require('../test-libs/jquery.js')
var _ = require('../test-libs/underscore')

window.$ = $
window._ = _

var wsloan = require('../../src/entries/pc')

describe('wsloan pc', function () {

})

